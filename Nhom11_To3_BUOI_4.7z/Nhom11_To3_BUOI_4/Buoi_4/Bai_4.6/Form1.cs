﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_4._6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        PhuongThuc pt = new PhuongThuc();
        private void radXuat_CheckedChanged(object sender, EventArgs e)
        {
            pt.TaoMang();
            txNhap.Text = pt.XuatMang();
        }

        private void radGTNN_CheckedChanged(object sender, EventArgs e)
        {
            txtKQ.Text = "Giá trị nhỏ nhất là : " + pt.Min();
        }

        private void radLietKe_CheckedChanged(object sender, EventArgs e)
        {
            txtKQ.Text = "Các số chẳn là   " + pt.LietKe();
        }

        private void radTimSC_CheckedChanged(object sender, EventArgs e)
        {
            txtKQ.Text= "Số chẳn cuối cùng là :"+ pt.ChanCuoi();
        }

        private void radTSC_CheckedChanged(object sender, EventArgs e)
        {
            txtKQ.Text = "Tổng số chẳn cuối cùng là :" + pt.TongSC();
        }

        private void radTSL_CheckedChanged(object sender, EventArgs e)
        {
            txtKQ.Text = "Tổng số lẻ cuối cùng là :" + pt.TongSL();
        }

        private void radDLC_CheckedChanged(object sender, EventArgs e)
        {
            txtKQ.Text = "Số lượng giá trị chẳn là :" + pt.DiemSC();
        }

        private void radDSL_CheckedChanged(object sender, EventArgs e)
        {
            txtKQ.Text = "Số lượng giá trị chẳn là :" + pt.DiemSL();
        }
    }
    
}
