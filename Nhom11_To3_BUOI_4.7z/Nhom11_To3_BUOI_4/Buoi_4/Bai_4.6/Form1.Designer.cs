﻿
namespace Bai_4._6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txNhap = new System.Windows.Forms.TextBox();
            this.txtKQ = new System.Windows.Forms.TextBox();
            this.radXuat = new System.Windows.Forms.RadioButton();
            this.radGTNN = new System.Windows.Forms.RadioButton();
            this.radLietKe = new System.Windows.Forms.RadioButton();
            this.radTimSC = new System.Windows.Forms.RadioButton();
            this.radTSL = new System.Windows.Forms.RadioButton();
            this.radTSC = new System.Windows.Forms.RadioButton();
            this.radDLC = new System.Windows.Forms.RadioButton();
            this.radDSL = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txNhap);
            this.groupBox1.Location = new System.Drawing.Point(72, 30);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(495, 95);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Mảng Gốc";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtKQ);
            this.groupBox2.Location = new System.Drawing.Point(72, 154);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(495, 91);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Kết quả";
            // 
            // txNhap
            // 
            this.txNhap.Location = new System.Drawing.Point(12, 22);
            this.txNhap.Multiline = true;
            this.txNhap.Name = "txNhap";
            this.txNhap.Size = new System.Drawing.Size(462, 55);
            this.txNhap.TabIndex = 0;
            // 
            // txtKQ
            // 
            this.txtKQ.Location = new System.Drawing.Point(16, 18);
            this.txtKQ.Multiline = true;
            this.txtKQ.Name = "txtKQ";
            this.txtKQ.Size = new System.Drawing.Size(462, 55);
            this.txtKQ.TabIndex = 1;
            // 
            // radXuat
            // 
            this.radXuat.AutoSize = true;
            this.radXuat.Location = new System.Drawing.Point(12, 267);
            this.radXuat.Name = "radXuat";
            this.radXuat.Size = new System.Drawing.Size(97, 21);
            this.radXuat.TabIndex = 14;
            this.radXuat.TabStop = true;
            this.radXuat.Text = "Xuất Mảng";
            this.radXuat.UseVisualStyleBackColor = true;
            this.radXuat.CheckedChanged += new System.EventHandler(this.radXuat_CheckedChanged);
            // 
            // radGTNN
            // 
            this.radGTNN.AutoSize = true;
            this.radGTNN.Location = new System.Drawing.Point(12, 294);
            this.radGTNN.Name = "radGTNN";
            this.radGTNN.Size = new System.Drawing.Size(154, 21);
            this.radGTNN.TabIndex = 15;
            this.radGTNN.TabStop = true;
            this.radGTNN.Text = "Tìm Giá trị nhỏ nhất";
            this.radGTNN.UseVisualStyleBackColor = true;
            this.radGTNN.CheckedChanged += new System.EventHandler(this.radGTNN_CheckedChanged);
            // 
            // radLietKe
            // 
            this.radLietKe.AutoSize = true;
            this.radLietKe.Location = new System.Drawing.Point(12, 321);
            this.radLietKe.Name = "radLietKe";
            this.radLietKe.Size = new System.Drawing.Size(71, 21);
            this.radLietKe.TabIndex = 16;
            this.radLietKe.TabStop = true;
            this.radLietKe.Text = "Liệt kê";
            this.radLietKe.UseVisualStyleBackColor = true;
            this.radLietKe.CheckedChanged += new System.EventHandler(this.radLietKe_CheckedChanged);
            // 
            // radTimSC
            // 
            this.radTimSC.AutoSize = true;
            this.radTimSC.Location = new System.Drawing.Point(12, 348);
            this.radTimSC.Name = "radTimSC";
            this.radTimSC.Size = new System.Drawing.Size(247, 21);
            this.radTimSC.TabIndex = 17;
            this.radTimSC.TabStop = true;
            this.radTimSC.Text = "Tìm số chẳn cuối cùng trong mảng";
            this.radTimSC.UseVisualStyleBackColor = true;
            this.radTimSC.CheckedChanged += new System.EventHandler(this.radTimSC_CheckedChanged);
            // 
            // radTSL
            // 
            this.radTSL.AutoSize = true;
            this.radTSL.Location = new System.Drawing.Point(12, 375);
            this.radTSL.Name = "radTSL";
            this.radTSL.Size = new System.Drawing.Size(198, 21);
            this.radTSL.TabIndex = 18;
            this.radTSL.TabStop = true;
            this.radTSL.Text = "Tổng các số lẻ trong mảng";
            this.radTSL.UseVisualStyleBackColor = true;
            this.radTSL.CheckedChanged += new System.EventHandler(this.radTSL_CheckedChanged);
            // 
            // radTSC
            // 
            this.radTSC.AutoSize = true;
            this.radTSC.Location = new System.Drawing.Point(12, 402);
            this.radTSC.Name = "radTSC";
            this.radTSC.Size = new System.Drawing.Size(218, 21);
            this.radTSC.TabIndex = 19;
            this.radTSC.TabStop = true;
            this.radTSC.Text = "Tổng các số chẳn trong mảng";
            this.radTSC.UseVisualStyleBackColor = true;
            this.radTSC.CheckedChanged += new System.EventHandler(this.radTSC_CheckedChanged);
            // 
            // radDLC
            // 
            this.radDLC.AutoSize = true;
            this.radDLC.Location = new System.Drawing.Point(12, 429);
            this.radDLC.Name = "radDLC";
            this.radDLC.Size = new System.Drawing.Size(203, 21);
            this.radDLC.TabIndex = 20;
            this.radDLC.TabStop = true;
            this.radDLC.Text = "Điếm số lượng các số chẳn ";
            this.radDLC.UseVisualStyleBackColor = true;
            this.radDLC.CheckedChanged += new System.EventHandler(this.radDLC_CheckedChanged);
            // 
            // radDSL
            // 
            this.radDSL.AutoSize = true;
            this.radDSL.Location = new System.Drawing.Point(12, 456);
            this.radDSL.Name = "radDSL";
            this.radDSL.Size = new System.Drawing.Size(199, 21);
            this.radDSL.TabIndex = 21;
            this.radDSL.TabStop = true;
            this.radDSL.Text = "Điếm số lượng các giá trị lẻ";
            this.radDSL.UseVisualStyleBackColor = true;
            this.radDSL.CheckedChanged += new System.EventHandler(this.radDSL_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 528);
            this.Controls.Add(this.radDSL);
            this.Controls.Add(this.radDLC);
            this.Controls.Add(this.radTSC);
            this.Controls.Add(this.radTSL);
            this.Controls.Add(this.radTimSC);
            this.Controls.Add(this.radLietKe);
            this.Controls.Add(this.radGTNN);
            this.Controls.Add(this.radXuat);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txNhap;
        private System.Windows.Forms.TextBox txtKQ;
        private System.Windows.Forms.RadioButton radXuat;
        private System.Windows.Forms.RadioButton radGTNN;
        private System.Windows.Forms.RadioButton radLietKe;
        private System.Windows.Forms.RadioButton radTimSC;
        private System.Windows.Forms.RadioButton radTSL;
        private System.Windows.Forms.RadioButton radTSC;
        private System.Windows.Forms.RadioButton radDLC;
        private System.Windows.Forms.RadioButton radDSL;
    }
}

