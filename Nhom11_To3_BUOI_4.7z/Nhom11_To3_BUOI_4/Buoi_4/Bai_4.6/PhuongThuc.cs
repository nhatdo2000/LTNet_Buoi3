﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_4._6
{
    class PhuongThuc
    {
        int[] a;

        public void TaoMang()
        {
            a = new int[10];
            int num;
            Random rd = new Random();
            for (int i = 0; i < a.Length; i++)
            {
                num = rd.Next(1, 100);
                a[i] = num;
            }
        }

        public String XuatMang()
        {
            TaoMang();
            String chuoi = "";
            for (int i = 0; i < a.Length; i++)
                chuoi += a[i] + "  ";
            return chuoi;
        }
        public int Min()
        {
            int min = a[0];
            for (int i = 0; i < a.Length; i++)
            {
                if (min > a[i])
                    min = a[i];
            }

            return min;
        }
        public string LietKe()
        {
            string sc = " ";
            for(int i =0; i<a.Length;i++)
            {
                if (a[i] % 2 == 0)
                {
                    sc += a[i] + "   ";
                }

            }
            return sc;

        }
        public int TongSC()
        {
            int tong = 0;
            for(int i = 0;i<a.Length;i++)
            {
                if(a[i]%2==0)
                {
                    tong += a[i] ;
                }    
            } return tong;   
        }
        public int TongSL()
        {
            int tong = 0;
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] % 2 != 0)
                {
                    tong += a[i];
                }
            }
            return tong;
        }
        public int ChanCuoi()
        {
            int dem = 0;
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] % 2 == 0)
                    dem = a[i];

            }
            return dem;
        }
        public int DiemSC()
        {
            int dem=0;
            for(int i=0;i<a.Length;i++)
            {
                if(a[i]%2==0) 
                
                    dem++;
                    
            } return dem;   
        }
        public int DiemSL()
        {
            int dem = 0;
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] % 2 != 0)

                    dem++;

            }
            return dem;
        }
    }

}
