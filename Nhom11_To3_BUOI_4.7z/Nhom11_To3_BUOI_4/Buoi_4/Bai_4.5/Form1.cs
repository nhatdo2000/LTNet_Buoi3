﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_4._5
{
    public partial class Form1 : Form
    {
        PhuongThuc pt = new PhuongThuc();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnTong_Click(object sender, EventArgs e)
        {
            lblKQ.Text = "Tổng mảng là = " + pt.Tongmang();
        }

        private void btnXuat_Click(object sender, EventArgs e)
        {
           
            pt.XuatMang();
            
            lblMang.Text = pt.XuatMang();
           
        }

        private void btnDemLe_Click(object sender, EventArgs e)
        {
            lblKQ.Text = "Các phần tử lẻ = " + pt.DemSoLe();
        }

        private void btnTongLe_Click(object sender, EventArgs e)
        {
            lblKQ.Text = "Tổng các số lẻ là = " + pt.TongSoLe();
        }

        private void btnSoPTNN_Click(object sender, EventArgs e)
        {
            lblKQ.Text = "Phần tử nhỏ nhất là = " + pt.Min();
        }

        private void btnTang2_Click(object sender, EventArgs e)
        {
            lblKQ.Text = "Phần tử tăng lên 2 là = " + pt.Tanglen2();

        }

        private void btnSXTang_Click(object sender, EventArgs e)
        {
            
            pt.SXT();
            
            lblKQ.Text = " Các phần tử sắp xếp tăng là : " +pt.XuatMang();
            
                
        }

        private void SXGiam_Click(object sender, EventArgs e)
        {
            pt.SXG();
            lblKQ.Text = " Các phần tử sắp xếp giảm là : " +pt.XuatMang();
           
        }
    }
}
