﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_4._5
{
    class PhuongThuc
    {
        const int MAX = 10;
        int[] mang = new int[MAX];
        //private int tmp = 0;
        public int[] a
        {
            get { return mang; }
            set { mang = value; }
        }

        public void TaoMang()
        {
           
            int num;
            Random rd = new Random();
            for (int i = 0; i < a.Length; i++)
            {
                num = rd.Next(1, 10);
                a[i] = num;
            }
        }

        public String XuatMang()
        {
            TaoMang();
            String chuoi = "";
            for (int i = 0; i < a.Length; i++)
                chuoi += a[i] + "  ";
            return chuoi;
        }
        public int Tongmang()
        {
            int tong = 0;
            for (int i = 0; i < a.Length; i++)
            {
                tong += a[i];
            }
            return tong;
        }
        public int KtraChanLe(int so)
        {
            int kt;
            if (so % 2 == 0)
                kt = 0;
            else
                kt = 1;
            return kt;
        }
        public int DemSoLe()
        {
            int dem = 0;
            for (int i = 0; i < a.Length; i++)
            {
                if (KtraChanLe(a[i]) == 1)
                    dem++;
            }
            return dem;
        }
        public int TongSoLe()
        {
            int tong = 0;
            for (int i = 0; i < a.Length; i++)
            {
                if (KtraChanLe(a[i]) == 1)
                    tong += a[i];
            }
            return tong;
        }
        public int Min()
        {
            int min=a[0] ;
            for (int i = 0; i < a.Length; i++)
            {
                if (min > a[i])
                    min= a[i];
            }

            return min;
        }
        public string Tanglen2()
        {
            string chuoi = "";

            for (int i=0; i<a.Length;i++)
            {
                int n = a[i] + 2;
                chuoi += n.ToString()+ "  ";
            }
            return chuoi;

        }
        public void SXT()
        {
            int tn = 0;
            for(int i =0; i<a.Length -1;i++)
                for (int j=i+1;j<a.Length;j++)
                {
                    if(a[i]>a[j])
                    {
                        tn = a[i];
                        a[i] = a[j];
                        a[j] = tn;
                    }    
                }    

        }

        public void SXG()
        {
            int tn = 0;
            for (int i = 0; i < a.Length - 1 ; i++)
                for (int j = i + 1; j < a.Length; j++)
                {
                    if (a[i] < a[j])
                    {
                        tn = a[i];
                        a[i] = a[j];
                        a[j] = tn;
                    }
                }

        }
    }
}
