﻿
namespace Bai_4._5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblMang = new System.Windows.Forms.Label();
            this.SXGiam = new System.Windows.Forms.Button();
            this.btnSXTang = new System.Windows.Forms.Button();
            this.btnTang2 = new System.Windows.Forms.Button();
            this.btnSoPTNN = new System.Windows.Forms.Button();
            this.btnTongLe = new System.Windows.Forms.Button();
            this.btnDemLe = new System.Windows.Forms.Button();
            this.btnTong = new System.Windows.Forms.Button();
            this.btnXuat = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblKQ = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblMang);
            this.groupBox1.Location = new System.Drawing.Point(153, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(495, 95);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Mảng Gốc";
            // 
            // lblMang
            // 
            this.lblMang.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblMang.Location = new System.Drawing.Point(7, 30);
            this.lblMang.Name = "lblMang";
            this.lblMang.Size = new System.Drawing.Size(477, 39);
            this.lblMang.TabIndex = 0;
            this.lblMang.UseWaitCursor = true;
            // 
            // SXGiam
            // 
            this.SXGiam.Location = new System.Drawing.Point(413, 409);
            this.SXGiam.Margin = new System.Windows.Forms.Padding(4);
            this.SXGiam.Name = "SXGiam";
            this.SXGiam.Size = new System.Drawing.Size(224, 32);
            this.SXGiam.TabIndex = 19;
            this.SXGiam.Text = "Sắp mảng giảm";
            this.SXGiam.UseVisualStyleBackColor = true;
            this.SXGiam.Click += new System.EventHandler(this.SXGiam_Click);
            // 
            // btnSXTang
            // 
            this.btnSXTang.Location = new System.Drawing.Point(413, 354);
            this.btnSXTang.Margin = new System.Windows.Forms.Padding(4);
            this.btnSXTang.Name = "btnSXTang";
            this.btnSXTang.Size = new System.Drawing.Size(224, 32);
            this.btnSXTang.TabIndex = 18;
            this.btnSXTang.Text = "Sắp mảng tăng";
            this.btnSXTang.UseVisualStyleBackColor = true;
            this.btnSXTang.Click += new System.EventHandler(this.btnSXTang_Click);
            // 
            // btnTang2
            // 
            this.btnTang2.Location = new System.Drawing.Point(413, 299);
            this.btnTang2.Margin = new System.Windows.Forms.Padding(4);
            this.btnTang2.Name = "btnTang2";
            this.btnTang2.Size = new System.Drawing.Size(224, 32);
            this.btnTang2.TabIndex = 17;
            this.btnTang2.Text = "Tăng mỗi phần tử mảng lên 2";
            this.btnTang2.UseVisualStyleBackColor = true;
            this.btnTang2.Click += new System.EventHandler(this.btnTang2_Click);
            // 
            // btnSoPTNN
            // 
            this.btnSoPTNN.Location = new System.Drawing.Point(413, 248);
            this.btnSoPTNN.Margin = new System.Windows.Forms.Padding(4);
            this.btnSoPTNN.Name = "btnSoPTNN";
            this.btnSoPTNN.Size = new System.Drawing.Size(224, 32);
            this.btnSoPTNN.TabIndex = 16;
            this.btnSoPTNN.Text = "Tìm phần tử nhỏ nhất";
            this.btnSoPTNN.UseVisualStyleBackColor = true;
            this.btnSoPTNN.Click += new System.EventHandler(this.btnSoPTNN_Click);
            // 
            // btnTongLe
            // 
            this.btnTongLe.Location = new System.Drawing.Point(153, 409);
            this.btnTongLe.Margin = new System.Windows.Forms.Padding(4);
            this.btnTongLe.Name = "btnTongLe";
            this.btnTongLe.Size = new System.Drawing.Size(222, 32);
            this.btnTongLe.TabIndex = 15;
            this.btnTongLe.Text = "Tổng giá trị phần tử lẻ";
            this.btnTongLe.UseVisualStyleBackColor = true;
            this.btnTongLe.Click += new System.EventHandler(this.btnTongLe_Click);
            // 
            // btnDemLe
            // 
            this.btnDemLe.Location = new System.Drawing.Point(153, 354);
            this.btnDemLe.Margin = new System.Windows.Forms.Padding(4);
            this.btnDemLe.Name = "btnDemLe";
            this.btnDemLe.Size = new System.Drawing.Size(222, 32);
            this.btnDemLe.TabIndex = 14;
            this.btnDemLe.Text = "Đếm số phần tử lẻ";
            this.btnDemLe.UseVisualStyleBackColor = true;
            this.btnDemLe.Click += new System.EventHandler(this.btnDemLe_Click);
            // 
            // btnTong
            // 
            this.btnTong.Location = new System.Drawing.Point(153, 299);
            this.btnTong.Margin = new System.Windows.Forms.Padding(4);
            this.btnTong.Name = "btnTong";
            this.btnTong.Size = new System.Drawing.Size(222, 32);
            this.btnTong.TabIndex = 13;
            this.btnTong.Text = "Tính tổng giá trị mảng";
            this.btnTong.UseVisualStyleBackColor = true;
            this.btnTong.Click += new System.EventHandler(this.btnTong_Click);
            // 
            // btnXuat
            // 
            this.btnXuat.Location = new System.Drawing.Point(153, 248);
            this.btnXuat.Margin = new System.Windows.Forms.Padding(4);
            this.btnXuat.Name = "btnXuat";
            this.btnXuat.Size = new System.Drawing.Size(222, 32);
            this.btnXuat.TabIndex = 12;
            this.btnXuat.Text = "Xuất mảng ngẫu nhiên";
            this.btnXuat.UseVisualStyleBackColor = true;
            this.btnXuat.Click += new System.EventHandler(this.btnXuat_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblKQ);
            this.groupBox2.Location = new System.Drawing.Point(153, 124);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(495, 91);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Kết quả";
            // 
            // lblKQ
            // 
            this.lblKQ.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblKQ.Location = new System.Drawing.Point(9, 26);
            this.lblKQ.Name = "lblKQ";
            this.lblKQ.Size = new System.Drawing.Size(477, 39);
            this.lblKQ.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(763, 497);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.SXGiam);
            this.Controls.Add(this.btnSXTang);
            this.Controls.Add(this.btnTang2);
            this.Controls.Add(this.btnSoPTNN);
            this.Controls.Add(this.btnTongLe);
            this.Controls.Add(this.btnDemLe);
            this.Controls.Add(this.btnTong);
            this.Controls.Add(this.btnXuat);
            this.Controls.Add(this.groupBox2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button SXGiam;
        private System.Windows.Forms.Button btnSXTang;
        private System.Windows.Forms.Button btnTang2;
        private System.Windows.Forms.Button btnSoPTNN;
        private System.Windows.Forms.Button btnTongLe;
        private System.Windows.Forms.Button btnDemLe;
        private System.Windows.Forms.Button btnTong;
        private System.Windows.Forms.Button btnXuat;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblMang;
        private System.Windows.Forms.Label lblKQ;
    }
}

