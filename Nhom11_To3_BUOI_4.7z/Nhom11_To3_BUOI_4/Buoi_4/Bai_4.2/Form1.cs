﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_4._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLamlai_Click(object sender, EventArgs e)
        {
            txtNhap.Clear();
            txtKTSHH.Clear();
            
            txtNhap.Focus();
        }

        private void txtNhap_TextChanged(object sender, EventArgs e)
        {
            int b;
            if(int.TryParse(txtNhap.Text,out b))
                if(PhuongThuc.KTSHH(b))
                {
                    txtKTSHH.Text = b.ToString() + " là số hoàn hảo";
                    string kq = "";
                    for (int i = 1; i <= b; i++)
                        if (PhuongThuc.KTSHH(i))
                            kq += i.ToString() + " ";
                    MessageBox.Show(kq);
                }
                else
                {
                    txtKTSHH.Text = b.ToString() +  " không phải là số hoàn hảo";
                    string kq = "";
                    for (int i = 1; i <= b; i++)
                        if (PhuongThuc.KTSHH(i))
                            kq += i.ToString() + " ";
                    MessageBox.Show(kq);


                }
            else
            {
                txtNhap.Focus();
            } 
                
        }
    }
}
