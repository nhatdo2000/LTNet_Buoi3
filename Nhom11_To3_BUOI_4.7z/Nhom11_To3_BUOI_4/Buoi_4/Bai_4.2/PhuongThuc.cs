﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai_4._2
{
    class PhuongThuc
    {
        public static bool KTSHH(int n)
        {
            int shh = 0 ;
           
            for (int i = 1; i < n ; i++)
                if (n % i == 0)
                    shh += i;
         
            if (shh == n)
                return true;
            return false;

        }
    }
}
