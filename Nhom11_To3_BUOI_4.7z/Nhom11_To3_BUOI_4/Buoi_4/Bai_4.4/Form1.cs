﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_4._4
{
   
    public partial class Form1 : Form
    {
        int a, b, c, d, r;
        float x, y, z;

        private void btnThucHien_Click(object sender, EventArgs e)
        {
            if (radHV.Checked == true)
            {
                d = Convert.ToInt32(txtNhap.Text);
                txtCV.Text = Convert.ToString(d * 4);
                txtDT.Text = Convert.ToString(d * d);
            }

            if (radHT.Checked == true)
            {
                r = Convert.ToInt32(txtNhapBK.Text);
                txtCVHT.Text = Convert.ToString(2 * 3.14 * r);
                txtDTHT.Text = Convert.ToString(3, 14 ^ 2 * 2);
            }

            if (radHCN.Checked == true)
            {
                a = Convert.ToInt32(txtNhapA.Text);
                b = Convert.ToInt32(txtNhapB.Text);
                txtCV_HCN.Text = Convert.ToString((a + b) * 2);
                txtDT_HCN.Text = Convert.ToString(a * b);
            }
            if (radHTG.Checked == true)
            {
                float a = float.Parse(txtNhapCanhA.Text);
                float b = float.Parse(txtNhapCanhB.Text);
                float c = float.Parse(txtNhapCanhC.Text);


                x = a * a;
                y = b * b;
                z = c * c;

                if (x == y || y == z || z == x)
                {
                    if (x == y && y == z)
                        txtKT_TamGiac.Text = ("Tam Giác Đều");
                    else
                    {
                        if (x == y + z || y == x + z || z == x + y)
                            txtKT_TamGiac.Text = ("Tam Giác Vuông Cân");
                        else
                            txtKT_TamGiac.Text = ("Tam Giác Thường");
                    }
                }
                else
                {
                    if (x == y + z || y == x + z || z == x + y)
                        txtKT_TamGiac.Text = ("Tam Giác Vuông");
                    else
                        txtKT_TamGiac.Text = ("Tam Giác Thường");
                }

                P = (a + b + c) / 2;
                S = Math.Sqrt(P * (P - a) * (P - b) * (P - c));

                txtCV_HTG.Text = Convert.ToString(S);
                txtDT_HTG.Text = Convert.ToString(P);

            }
            else
                txtKT_TamGiac.Text = ("Ba cạnh không tạo thành tam giác");
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtCV.ResetText();
            txtCVHT.ResetText();
            txtCV_HCN.ResetText();
            txtCV_HTG.ResetText();
            txtDT.ResetText();
            txtDTHT.ResetText();
            txtDT_HCN.ResetText();
            txtDT_HTG.ResetText();
            txtKT_TamGiac.ResetText();
            
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        double P, S;
        public Form1()
        {
            InitializeComponent();
        }

        private void radHT_CheckedChanged(object sender, EventArgs e)
        {
            grpHinhChuNhat.Visible = false;
            grpHinhTamGiac.Visible = false;
            grpHinhTron.Visible = true;
            grpHinhVuong.Visible = false;
        }

        private void radHTG_CheckedChanged(object sender, EventArgs e)
        {
            grpHinhChuNhat.Visible = false;
            grpHinhTamGiac.Visible = true;
            grpHinhTron.Visible = false;
            grpHinhVuong.Visible = false;
        }

        private void radHV_CheckedChanged(object sender, EventArgs e)
        {
            grpHinhChuNhat.Visible = false;
            grpHinhTamGiac.Visible = false;
            grpHinhTron.Visible =false;
            grpHinhVuong.Visible = true;
        }

        private void radHCN_CheckedChanged(object sender, EventArgs e)
        {
            grpHinhChuNhat.Visible = true;
            grpHinhTamGiac.Visible = false;
            grpHinhTron.Visible = false;
            grpHinhVuong.Visible = false;
        }
    }
}
