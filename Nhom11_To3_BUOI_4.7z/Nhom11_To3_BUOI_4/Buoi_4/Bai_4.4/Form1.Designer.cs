﻿
namespace Bai_4._4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpHinhChuNhat = new System.Windows.Forms.GroupBox();
            this.txtDT_HCN = new System.Windows.Forms.TextBox();
            this.txtCV_HCN = new System.Windows.Forms.TextBox();
            this.txtNhapB = new System.Windows.Forms.TextBox();
            this.txtNhapA = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDTHT = new System.Windows.Forms.TextBox();
            this.txtCVHT = new System.Windows.Forms.TextBox();
            this.txtNhapBK = new System.Windows.Forms.TextBox();
            this.txtKT_TamGiac = new System.Windows.Forms.TextBox();
            this.txtDT_HTG = new System.Windows.Forms.TextBox();
            this.txtCV_HTG = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtNhapCanhC = new System.Windows.Forms.TextBox();
            this.txtNhapCanhB = new System.Windows.Forms.TextBox();
            this.txtNhapCanhA = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.grpHinhTamGiac = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtCV = new System.Windows.Forms.TextBox();
            this.radHTG = new System.Windows.Forms.RadioButton();
            this.grpHinhTron = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.radHCN = new System.Windows.Forms.RadioButton();
            this.radHT = new System.Windows.Forms.RadioButton();
            this.radHV = new System.Windows.Forms.RadioButton();
            this.grpHinhVuong = new System.Windows.Forms.GroupBox();
            this.txtDT = new System.Windows.Forms.TextBox();
            this.txtNhap = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnThucHien = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grpHinhChuNhat.SuspendLayout();
            this.grpHinhTamGiac.SuspendLayout();
            this.grpHinhTron.SuspendLayout();
            this.grpHinhVuong.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpHinhChuNhat
            // 
            this.grpHinhChuNhat.Controls.Add(this.txtDT_HCN);
            this.grpHinhChuNhat.Controls.Add(this.txtCV_HCN);
            this.grpHinhChuNhat.Controls.Add(this.txtNhapB);
            this.grpHinhChuNhat.Controls.Add(this.txtNhapA);
            this.grpHinhChuNhat.Controls.Add(this.label13);
            this.grpHinhChuNhat.Controls.Add(this.label12);
            this.grpHinhChuNhat.Controls.Add(this.label11);
            this.grpHinhChuNhat.Controls.Add(this.label10);
            this.grpHinhChuNhat.Location = new System.Drawing.Point(59, 306);
            this.grpHinhChuNhat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpHinhChuNhat.Name = "grpHinhChuNhat";
            this.grpHinhChuNhat.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpHinhChuNhat.Size = new System.Drawing.Size(278, 194);
            this.grpHinhChuNhat.TabIndex = 20;
            this.grpHinhChuNhat.TabStop = false;
            this.grpHinhChuNhat.Text = "Hình Chữ Nhật";
            // 
            // txtDT_HCN
            // 
            this.txtDT_HCN.Location = new System.Drawing.Point(113, 155);
            this.txtDT_HCN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDT_HCN.Name = "txtDT_HCN";
            this.txtDT_HCN.Size = new System.Drawing.Size(148, 22);
            this.txtDT_HCN.TabIndex = 7;
            // 
            // txtCV_HCN
            // 
            this.txtCV_HCN.Location = new System.Drawing.Point(112, 117);
            this.txtCV_HCN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCV_HCN.Name = "txtCV_HCN";
            this.txtCV_HCN.Size = new System.Drawing.Size(150, 22);
            this.txtCV_HCN.TabIndex = 6;
            // 
            // txtNhapB
            // 
            this.txtNhapB.Location = new System.Drawing.Point(110, 71);
            this.txtNhapB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNhapB.Name = "txtNhapB";
            this.txtNhapB.Size = new System.Drawing.Size(151, 22);
            this.txtNhapB.TabIndex = 5;
            // 
            // txtNhapA
            // 
            this.txtNhapA.Location = new System.Drawing.Point(110, 32);
            this.txtNhapA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNhapA.Name = "txtNhapA";
            this.txtNhapA.Size = new System.Drawing.Size(152, 22);
            this.txtNhapA.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(17, 160);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 17);
            this.label13.TabIndex = 3;
            this.label13.Text = "Diện Tích:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(28, 122);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 17);
            this.label12.TabIndex = 2;
            this.label12.Text = "Chu Vi:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(28, 76);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 17);
            this.label11.TabIndex = 1;
            this.label11.Text = "Nhập B:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(28, 37);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 17);
            this.label10.TabIndex = 0;
            this.label10.Text = "Nhập A:";
            // 
            // txtDTHT
            // 
            this.txtDTHT.Location = new System.Drawing.Point(117, 98);
            this.txtDTHT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDTHT.Name = "txtDTHT";
            this.txtDTHT.Size = new System.Drawing.Size(136, 22);
            this.txtDTHT.TabIndex = 5;
            // 
            // txtCVHT
            // 
            this.txtCVHT.Location = new System.Drawing.Point(117, 64);
            this.txtCVHT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCVHT.Name = "txtCVHT";
            this.txtCVHT.Size = new System.Drawing.Size(136, 22);
            this.txtCVHT.TabIndex = 4;
            // 
            // txtNhapBK
            // 
            this.txtNhapBK.Location = new System.Drawing.Point(117, 28);
            this.txtNhapBK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNhapBK.Name = "txtNhapBK";
            this.txtNhapBK.Size = new System.Drawing.Size(136, 22);
            this.txtNhapBK.TabIndex = 3;
            // 
            // txtKT_TamGiac
            // 
            this.txtKT_TamGiac.Location = new System.Drawing.Point(21, 175);
            this.txtKT_TamGiac.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtKT_TamGiac.Name = "txtKT_TamGiac";
            this.txtKT_TamGiac.Size = new System.Drawing.Size(239, 22);
            this.txtKT_TamGiac.TabIndex = 10;
            // 
            // txtDT_HTG
            // 
            this.txtDT_HTG.Location = new System.Drawing.Point(108, 135);
            this.txtDT_HTG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDT_HTG.Name = "txtDT_HTG";
            this.txtDT_HTG.Size = new System.Drawing.Size(152, 22);
            this.txtDT_HTG.TabIndex = 9;
            // 
            // txtCV_HTG
            // 
            this.txtCV_HTG.Location = new System.Drawing.Point(108, 102);
            this.txtCV_HTG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCV_HTG.Name = "txtCV_HTG";
            this.txtCV_HTG.Size = new System.Drawing.Size(152, 22);
            this.txtCV_HTG.TabIndex = 8;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 140);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(72, 17);
            this.label18.TabIndex = 7;
            this.label18.Text = "Diện Tích:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(29, 107);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 17);
            this.label17.TabIndex = 6;
            this.label17.Text = "Chu Vi:";
            // 
            // txtNhapCanhC
            // 
            this.txtNhapCanhC.Location = new System.Drawing.Point(197, 66);
            this.txtNhapCanhC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNhapCanhC.Name = "txtNhapCanhC";
            this.txtNhapCanhC.Size = new System.Drawing.Size(64, 22);
            this.txtNhapCanhC.TabIndex = 5;
            // 
            // txtNhapCanhB
            // 
            this.txtNhapCanhB.Location = new System.Drawing.Point(112, 66);
            this.txtNhapCanhB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNhapCanhB.Name = "txtNhapCanhB";
            this.txtNhapCanhB.Size = new System.Drawing.Size(64, 22);
            this.txtNhapCanhB.TabIndex = 4;
            // 
            // txtNhapCanhA
            // 
            this.txtNhapCanhA.Location = new System.Drawing.Point(23, 66);
            this.txtNhapCanhA.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNhapCanhA.Name = "txtNhapCanhA";
            this.txtNhapCanhA.Size = new System.Drawing.Size(64, 22);
            this.txtNhapCanhA.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(203, 35);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 17);
            this.label16.TabIndex = 2;
            this.label16.Text = "Nhập C:";
            // 
            // grpHinhTamGiac
            // 
            this.grpHinhTamGiac.Controls.Add(this.txtKT_TamGiac);
            this.grpHinhTamGiac.Controls.Add(this.txtDT_HTG);
            this.grpHinhTamGiac.Controls.Add(this.txtCV_HTG);
            this.grpHinhTamGiac.Controls.Add(this.label18);
            this.grpHinhTamGiac.Controls.Add(this.label17);
            this.grpHinhTamGiac.Controls.Add(this.txtNhapCanhC);
            this.grpHinhTamGiac.Controls.Add(this.txtNhapCanhB);
            this.grpHinhTamGiac.Controls.Add(this.txtNhapCanhA);
            this.grpHinhTamGiac.Controls.Add(this.label16);
            this.grpHinhTamGiac.Controls.Add(this.label15);
            this.grpHinhTamGiac.Controls.Add(this.label14);
            this.grpHinhTamGiac.Location = new System.Drawing.Point(402, 306);
            this.grpHinhTamGiac.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpHinhTamGiac.Name = "grpHinhTamGiac";
            this.grpHinhTamGiac.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpHinhTamGiac.Size = new System.Drawing.Size(277, 206);
            this.grpHinhTamGiac.TabIndex = 21;
            this.grpHinhTamGiac.TabStop = false;
            this.grpHinhTamGiac.Text = "Hình Tam Giác";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(118, 35);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 17);
            this.label15.TabIndex = 1;
            this.label15.Text = "Nhập B:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(28, 35);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 17);
            this.label14.TabIndex = 0;
            this.label14.Text = "Nhập A:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(35, 100);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 17);
            this.label9.TabIndex = 2;
            this.label9.Text = "Diện Tích:";
            // 
            // txtCV
            // 
            this.txtCV.Location = new System.Drawing.Point(120, 71);
            this.txtCV.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCV.Name = "txtCV";
            this.txtCV.Size = new System.Drawing.Size(136, 22);
            this.txtCV.TabIndex = 4;
            // 
            // radHTG
            // 
            this.radHTG.AutoSize = true;
            this.radHTG.Location = new System.Drawing.Point(138, 33);
            this.radHTG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radHTG.Name = "radHTG";
            this.radHTG.Size = new System.Drawing.Size(123, 21);
            this.radHTG.TabIndex = 3;
            this.radHTG.TabStop = true;
            this.radHTG.Text = "Hình Tam Giác";
            this.radHTG.UseVisualStyleBackColor = true;
            this.radHTG.CheckedChanged += new System.EventHandler(this.radHTG_CheckedChanged);
            // 
            // grpHinhTron
            // 
            this.grpHinhTron.Controls.Add(this.txtDTHT);
            this.grpHinhTron.Controls.Add(this.txtCVHT);
            this.grpHinhTron.Controls.Add(this.txtNhapBK);
            this.grpHinhTron.Controls.Add(this.label9);
            this.grpHinhTron.Controls.Add(this.label8);
            this.grpHinhTron.Controls.Add(this.label7);
            this.grpHinhTron.Location = new System.Drawing.Point(401, 15);
            this.grpHinhTron.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpHinhTron.Name = "grpHinhTron";
            this.grpHinhTron.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpHinhTron.Size = new System.Drawing.Size(275, 132);
            this.grpHinhTron.TabIndex = 19;
            this.grpHinhTron.TabStop = false;
            this.grpHinhTron.Text = "Hình Tròn";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(52, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 17);
            this.label8.TabIndex = 1;
            this.label8.Text = "Chu Vi:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 17);
            this.label7.TabIndex = 0;
            this.label7.Text = "Nhập Bán Kính:";
            // 
            // radHCN
            // 
            this.radHCN.AutoSize = true;
            this.radHCN.Location = new System.Drawing.Point(140, 66);
            this.radHCN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radHCN.Name = "radHCN";
            this.radHCN.Size = new System.Drawing.Size(121, 21);
            this.radHCN.TabIndex = 2;
            this.radHCN.TabStop = true;
            this.radHCN.Text = "Hình Chữ Nhật";
            this.radHCN.UseVisualStyleBackColor = true;
            this.radHCN.CheckedChanged += new System.EventHandler(this.radHCN_CheckedChanged);
            // 
            // radHT
            // 
            this.radHT.AutoSize = true;
            this.radHT.Location = new System.Drawing.Point(17, 33);
            this.radHT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radHT.Name = "radHT";
            this.radHT.Size = new System.Drawing.Size(92, 21);
            this.radHT.TabIndex = 1;
            this.radHT.TabStop = true;
            this.radHT.Text = "Hình Tròn";
            this.radHT.UseVisualStyleBackColor = true;
            this.radHT.CheckedChanged += new System.EventHandler(this.radHT_CheckedChanged);
            // 
            // radHV
            // 
            this.radHV.AutoSize = true;
            this.radHV.Location = new System.Drawing.Point(17, 70);
            this.radHV.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radHV.Name = "radHV";
            this.radHV.Size = new System.Drawing.Size(103, 21);
            this.radHV.TabIndex = 0;
            this.radHV.TabStop = true;
            this.radHV.Text = "Hình Vuông";
            this.radHV.UseVisualStyleBackColor = true;
            this.radHV.CheckedChanged += new System.EventHandler(this.radHV_CheckedChanged);
            // 
            // grpHinhVuong
            // 
            this.grpHinhVuong.Controls.Add(this.txtDT);
            this.grpHinhVuong.Controls.Add(this.txtCV);
            this.grpHinhVuong.Controls.Add(this.txtNhap);
            this.grpHinhVuong.Controls.Add(this.label6);
            this.grpHinhVuong.Controls.Add(this.label5);
            this.grpHinhVuong.Controls.Add(this.label4);
            this.grpHinhVuong.Location = new System.Drawing.Point(401, 151);
            this.grpHinhVuong.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpHinhVuong.Name = "grpHinhVuong";
            this.grpHinhVuong.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grpHinhVuong.Size = new System.Drawing.Size(278, 142);
            this.grpHinhVuong.TabIndex = 18;
            this.grpHinhVuong.TabStop = false;
            this.grpHinhVuong.Text = "Hình Vuông";
            // 
            // txtDT
            // 
            this.txtDT.Location = new System.Drawing.Point(120, 105);
            this.txtDT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtDT.Name = "txtDT";
            this.txtDT.Size = new System.Drawing.Size(136, 22);
            this.txtDT.TabIndex = 5;
            // 
            // txtNhap
            // 
            this.txtNhap.Location = new System.Drawing.Point(120, 32);
            this.txtNhap.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNhap.Name = "txtNhap";
            this.txtNhap.Size = new System.Drawing.Size(136, 22);
            this.txtNhap.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 17);
            this.label6.TabIndex = 2;
            this.label6.Text = "Diện Tích:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(48, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 17);
            this.label5.TabIndex = 1;
            this.label5.Text = "Chu Vi:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "Nhập Cạnh A:";
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(280, 261);
            this.btnThoat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(81, 32);
            this.btnThoat.TabIndex = 17;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(182, 261);
            this.btnReset.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(81, 32);
            this.btnReset.TabIndex = 16;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnThucHien
            // 
            this.btnThucHien.Location = new System.Drawing.Point(59, 261);
            this.btnThucHien.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnThucHien.Name = "btnThucHien";
            this.btnThucHien.Size = new System.Drawing.Size(95, 32);
            this.btnThucHien.TabIndex = 15;
            this.btnThucHien.Text = "Thực Hiện";
            this.btnThucHien.UseVisualStyleBackColor = true;
            this.btnThucHien.Click += new System.EventHandler(this.btnThucHien_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radHTG);
            this.groupBox1.Controls.Add(this.radHCN);
            this.groupBox1.Controls.Add(this.radHT);
            this.groupBox1.Controls.Add(this.radHV);
            this.groupBox1.Location = new System.Drawing.Point(59, 126);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(278, 111);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chọn";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(73, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(207, 17);
            this.label3.TabIndex = 13;
            this.label3.Text = "Hình Tam Giác - Hình Chữ Nhật";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(105, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "Hình Tròn - Hình Vuông";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(89, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Tìm Chu Vi và Diện Tích";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(854, 523);
            this.Controls.Add(this.grpHinhChuNhat);
            this.Controls.Add(this.grpHinhTamGiac);
            this.Controls.Add(this.grpHinhTron);
            this.Controls.Add(this.grpHinhVuong);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnThucHien);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.grpHinhChuNhat.ResumeLayout(false);
            this.grpHinhChuNhat.PerformLayout();
            this.grpHinhTamGiac.ResumeLayout(false);
            this.grpHinhTamGiac.PerformLayout();
            this.grpHinhTron.ResumeLayout(false);
            this.grpHinhTron.PerformLayout();
            this.grpHinhVuong.ResumeLayout(false);
            this.grpHinhVuong.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpHinhChuNhat;
        private System.Windows.Forms.TextBox txtDT_HCN;
        private System.Windows.Forms.TextBox txtCV_HCN;
        private System.Windows.Forms.TextBox txtNhapB;
        private System.Windows.Forms.TextBox txtNhapA;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtDTHT;
        private System.Windows.Forms.TextBox txtCVHT;
        private System.Windows.Forms.TextBox txtNhapBK;
        private System.Windows.Forms.TextBox txtKT_TamGiac;
        private System.Windows.Forms.TextBox txtDT_HTG;
        private System.Windows.Forms.TextBox txtCV_HTG;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtNhapCanhC;
        private System.Windows.Forms.TextBox txtNhapCanhB;
        private System.Windows.Forms.TextBox txtNhapCanhA;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox grpHinhTamGiac;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtCV;
        private System.Windows.Forms.RadioButton radHTG;
        private System.Windows.Forms.GroupBox grpHinhTron;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton radHCN;
        private System.Windows.Forms.RadioButton radHT;
        private System.Windows.Forms.RadioButton radHV;
        private System.Windows.Forms.GroupBox grpHinhVuong;
        private System.Windows.Forms.TextBox txtDT;
        private System.Windows.Forms.TextBox txtNhap;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnThucHien;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

