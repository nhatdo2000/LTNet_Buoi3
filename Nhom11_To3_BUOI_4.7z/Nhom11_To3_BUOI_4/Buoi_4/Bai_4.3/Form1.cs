﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_4._3
{
    public partial class Form1 : Form
    {
        float tu, tu1, tu2, mau, mau1, mau2,USC;

        private void btnTru_Click(object sender, EventArgs e)
        {
            this.grpKQ.Text = "Kết quả trừ";
            tu = (tu1 * mau2) - (tu2 * mau1);
            mau = mau1 * mau2;
            USC = PhuongThuc.USCLN(tu, mau);
            txtTuSo3.Text = Convert.ToString(tu / USC);
            txtMauSo3.Text = Convert.ToString(mau / USC);

        }

        private void btnNhan_Click(object sender, EventArgs e)
        {
            this.grpKQ.Text = "Kết quả nhân";
            tu = tu1 * tu2;
            mau = mau1 * mau2;
            USC = PhuongThuc.USCLN(tu, mau);
            txtTuSo3.Text = Convert.ToString(tu / USC);
            txtMauSo3.Text = Convert.ToString(mau / USC);
        }

        private void btnChia_Click(object sender, EventArgs e)
        {
            this.grpKQ.Text = "Kết quả nhân";
            tu = tu1 * mau2;
            mau = mau1 * tu2;
            USC = PhuongThuc.USCLN(tu, mau);
            txtTuSo3.Text = Convert.ToString(tu / USC);
            txtMauSo3.Text = Convert.ToString(mau / USC);
        }

        private void grpPhepTinh_Enter(object sender, EventArgs e)
        {
            tu1 = float.Parse(txtTuSo1.Text);
            tu2 = float.Parse(txtTuSo2.Text);
            mau1 = float.Parse(txtMauso1.Text);
            mau2 = float.Parse(txtMauSo2.Text);
        }

       
       
        private void btnCong_Click(object sender, EventArgs e)
        {

            this.grpKQ.Text = "Kết quả cộng";
            tu = (tu1 * mau2) + (tu2 * mau1);
            mau = mau1 * mau2;
            USC = PhuongThuc.USCLN(tu, mau);
            txtTuSo3.Text = Convert.ToString(tu / USC);
            txtMauSo3.Text = Convert.ToString(mau / USC);

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnTieptuc_Click(object sender, EventArgs e)
        {
            txtTuSo1.ResetText();
            txtTuSo2.ResetText();
            txtTuSo3.ResetText();
            txtMauso1.ResetText();
            txtMauSo2.ResetText();
            txtMauSo3.ResetText();
            grpKQ.Text = "Kết Quả";
            tu = tu1 = tu2 = mau = mau1 = mau2 = USC = 0;
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtTuSo1.Focus();
        }
    }
}
