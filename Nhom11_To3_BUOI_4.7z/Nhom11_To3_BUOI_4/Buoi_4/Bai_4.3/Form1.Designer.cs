﻿
namespace Bai_4._3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpPhanSo = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTuSo1 = new System.Windows.Forms.TextBox();
            this.txtMauso1 = new System.Windows.Forms.TextBox();
            this.grpPhanSo2 = new System.Windows.Forms.GroupBox();
            this.txtMauSo2 = new System.Windows.Forms.TextBox();
            this.txtTuSo2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.grpKQ = new System.Windows.Forms.GroupBox();
            this.txtMauSo3 = new System.Windows.Forms.TextBox();
            this.txtTuSo3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.grpPhepTinh = new System.Windows.Forms.GroupBox();
            this.btnCong = new System.Windows.Forms.Button();
            this.btnNhan = new System.Windows.Forms.Button();
            this.btnTru = new System.Windows.Forms.Button();
            this.btnChia = new System.Windows.Forms.Button();
            this.btnTieptuc = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.grpPhanSo.SuspendLayout();
            this.grpPhanSo2.SuspendLayout();
            this.grpKQ.SuspendLayout();
            this.grpPhepTinh.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpPhanSo
            // 
            this.grpPhanSo.Controls.Add(this.txtMauso1);
            this.grpPhanSo.Controls.Add(this.txtTuSo1);
            this.grpPhanSo.Controls.Add(this.label2);
            this.grpPhanSo.Controls.Add(this.label1);
            this.grpPhanSo.Location = new System.Drawing.Point(22, 25);
            this.grpPhanSo.Name = "grpPhanSo";
            this.grpPhanSo.Size = new System.Drawing.Size(256, 122);
            this.grpPhanSo.TabIndex = 0;
            this.grpPhanSo.TabStop = false;
            this.grpPhanSo.Text = "Phân số 1 :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Tử số :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Mẫu số :";
            // 
            // txtTuSo1
            // 
            this.txtTuSo1.Location = new System.Drawing.Point(74, 34);
            this.txtTuSo1.Name = "txtTuSo1";
            this.txtTuSo1.Size = new System.Drawing.Size(162, 22);
            this.txtTuSo1.TabIndex = 3;
            // 
            // txtMauso1
            // 
            this.txtMauso1.Location = new System.Drawing.Point(74, 77);
            this.txtMauso1.Name = "txtMauso1";
            this.txtMauso1.Size = new System.Drawing.Size(162, 22);
            this.txtMauso1.TabIndex = 4;
            // 
            // grpPhanSo2
            // 
            this.grpPhanSo2.Controls.Add(this.txtMauSo2);
            this.grpPhanSo2.Controls.Add(this.txtTuSo2);
            this.grpPhanSo2.Controls.Add(this.label3);
            this.grpPhanSo2.Controls.Add(this.label4);
            this.grpPhanSo2.Location = new System.Drawing.Point(318, 25);
            this.grpPhanSo2.Name = "grpPhanSo2";
            this.grpPhanSo2.Size = new System.Drawing.Size(256, 122);
            this.grpPhanSo2.TabIndex = 5;
            this.grpPhanSo2.TabStop = false;
            this.grpPhanSo2.Text = "Phân số 2 :";
            // 
            // txtMauSo2
            // 
            this.txtMauSo2.Location = new System.Drawing.Point(74, 77);
            this.txtMauSo2.Name = "txtMauSo2";
            this.txtMauSo2.Size = new System.Drawing.Size(162, 22);
            this.txtMauSo2.TabIndex = 4;
            // 
            // txtTuSo2
            // 
            this.txtTuSo2.Location = new System.Drawing.Point(74, 34);
            this.txtTuSo2.Name = "txtTuSo2";
            this.txtTuSo2.Size = new System.Drawing.Size(162, 22);
            this.txtTuSo2.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mẫu số :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 17);
            this.label4.TabIndex = 1;
            this.label4.Text = "Tử số :";
            // 
            // grpKQ
            // 
            this.grpKQ.Controls.Add(this.txtMauSo3);
            this.grpKQ.Controls.Add(this.txtTuSo3);
            this.grpKQ.Controls.Add(this.label5);
            this.grpKQ.Controls.Add(this.label6);
            this.grpKQ.Location = new System.Drawing.Point(318, 189);
            this.grpKQ.Name = "grpKQ";
            this.grpKQ.Size = new System.Drawing.Size(256, 122);
            this.grpKQ.TabIndex = 6;
            this.grpKQ.TabStop = false;
            this.grpKQ.Text = "Kết quả cộng";
            // 
            // txtMauSo3
            // 
            this.txtMauSo3.Location = new System.Drawing.Point(74, 77);
            this.txtMauSo3.Name = "txtMauSo3";
            this.txtMauSo3.Size = new System.Drawing.Size(162, 22);
            this.txtMauSo3.TabIndex = 4;
            // 
            // txtTuSo3
            // 
            this.txtTuSo3.Location = new System.Drawing.Point(74, 34);
            this.txtTuSo3.Name = "txtTuSo3";
            this.txtTuSo3.Size = new System.Drawing.Size(162, 22);
            this.txtTuSo3.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "Mẫu số :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 17);
            this.label6.TabIndex = 1;
            this.label6.Text = "Tử số :";
            // 
            // grpPhepTinh
            // 
            this.grpPhepTinh.Controls.Add(this.btnChia);
            this.grpPhepTinh.Controls.Add(this.btnTru);
            this.grpPhepTinh.Controls.Add(this.btnNhan);
            this.grpPhepTinh.Controls.Add(this.btnCong);
            this.grpPhepTinh.Location = new System.Drawing.Point(22, 189);
            this.grpPhepTinh.Name = "grpPhepTinh";
            this.grpPhepTinh.Size = new System.Drawing.Size(256, 122);
            this.grpPhepTinh.TabIndex = 7;
            this.grpPhepTinh.TabStop = false;
            this.grpPhepTinh.Text = "Phép Tính :";
            this.grpPhepTinh.Enter += new System.EventHandler(this.grpPhepTinh_Enter);
            // 
            // btnCong
            // 
            this.btnCong.Location = new System.Drawing.Point(6, 26);
            this.btnCong.Name = "btnCong";
            this.btnCong.Size = new System.Drawing.Size(89, 30);
            this.btnCong.TabIndex = 8;
            this.btnCong.Text = "Cộng";
            this.btnCong.UseVisualStyleBackColor = true;
            this.btnCong.Click += new System.EventHandler(this.btnCong_Click);
            // 
            // btnNhan
            // 
            this.btnNhan.Location = new System.Drawing.Point(6, 73);
            this.btnNhan.Name = "btnNhan";
            this.btnNhan.Size = new System.Drawing.Size(89, 30);
            this.btnNhan.TabIndex = 9;
            this.btnNhan.Text = "Nhân";
            this.btnNhan.UseVisualStyleBackColor = true;
            this.btnNhan.Click += new System.EventHandler(this.btnNhan_Click);
            // 
            // btnTru
            // 
            this.btnTru.Location = new System.Drawing.Point(110, 26);
            this.btnTru.Name = "btnTru";
            this.btnTru.Size = new System.Drawing.Size(89, 34);
            this.btnTru.TabIndex = 9;
            this.btnTru.Text = "Trừ";
            this.btnTru.UseVisualStyleBackColor = true;
            this.btnTru.Click += new System.EventHandler(this.btnTru_Click);
            // 
            // btnChia
            // 
            this.btnChia.Location = new System.Drawing.Point(110, 73);
            this.btnChia.Name = "btnChia";
            this.btnChia.Size = new System.Drawing.Size(89, 30);
            this.btnChia.TabIndex = 10;
            this.btnChia.Text = "Chia";
            this.btnChia.UseVisualStyleBackColor = true;
            this.btnChia.Click += new System.EventHandler(this.btnChia_Click);
            // 
            // btnTieptuc
            // 
            this.btnTieptuc.Location = new System.Drawing.Point(102, 346);
            this.btnTieptuc.Name = "btnTieptuc";
            this.btnTieptuc.Size = new System.Drawing.Size(119, 61);
            this.btnTieptuc.TabIndex = 8;
            this.btnTieptuc.Text = "Tiếp tục";
            this.btnTieptuc.UseVisualStyleBackColor = true;
            this.btnTieptuc.Click += new System.EventHandler(this.btnTieptuc_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Location = new System.Drawing.Point(318, 346);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(119, 61);
            this.btnThoat.TabIndex = 10;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnTieptuc);
            this.Controls.Add(this.grpPhepTinh);
            this.Controls.Add(this.grpKQ);
            this.Controls.Add(this.grpPhanSo2);
            this.Controls.Add(this.grpPhanSo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpPhanSo.ResumeLayout(false);
            this.grpPhanSo.PerformLayout();
            this.grpPhanSo2.ResumeLayout(false);
            this.grpPhanSo2.PerformLayout();
            this.grpKQ.ResumeLayout(false);
            this.grpKQ.PerformLayout();
            this.grpPhepTinh.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpPhanSo;
        private System.Windows.Forms.TextBox txtMauso1;
        private System.Windows.Forms.TextBox txtTuSo1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpPhanSo2;
        private System.Windows.Forms.TextBox txtMauSo2;
        private System.Windows.Forms.TextBox txtTuSo2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox grpKQ;
        private System.Windows.Forms.TextBox txtMauSo3;
        private System.Windows.Forms.TextBox txtTuSo3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox grpPhepTinh;
        private System.Windows.Forms.Button btnChia;
        private System.Windows.Forms.Button btnTru;
        private System.Windows.Forms.Button btnNhan;
        private System.Windows.Forms.Button btnCong;
        private System.Windows.Forms.Button btnTieptuc;
        private System.Windows.Forms.Button btnThoat;
    }
}

