﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_4._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        PhuongThuc tn = new PhuongThuc();
        
        private void txtNhap_TextChanged(object sender, EventArgs e)
        {
            int b;
            if(int.TryParse(txtNhap.Text, out b))
            {
                if(PhuongThuc.KTSNT(b))
                {
                    txtKTSNT.Text = b.ToString() + " là số nguyên tố";
                    string kq = "";
                    for (int i = 2; i < b; i++)
                        if (PhuongThuc.KTSNT(i))
                            kq += i.ToString() + "";
                    txtSNTNHN.Text = kq;
                }    


            }
            else
            {
                txtNhap.Focus();
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLamlai_Click(object sender, EventArgs e)
        {
            txtNhap.Clear();
            txtKTSNT.Clear();
            txtSNTNHN.Clear();
            txtNhap.Focus();
        }
    }
}
